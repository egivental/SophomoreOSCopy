#ifndef sSignal
#define sSignal

#define S_SIGSTOP 2 // Stops the thread that receives this
#define S_SIGCONT 4 // Continus the thread that receives this
#define S_SIGTERM 6 // Terminates the thread that receives this.

#endif
